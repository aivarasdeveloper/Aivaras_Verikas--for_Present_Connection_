# Frontend

Install:
```bash
npm install
```
Run:
```bash
npm run dev
```
Backend must run at http://localhost:5000