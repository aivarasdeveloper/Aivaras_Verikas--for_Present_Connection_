import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Groups from './pages/Groups';
import GroupDetails from './pages/GroupDetails';
import NewTransaction from './pages/NewTransaction';
const NotFound = () => <div>404 Not Found</div>;
export default function App() {
return (
<BrowserRouter>
<Routes>
<Route path='/' element={<Groups />} />
<Route path='/group/:id' element={<GroupDetails />} />
<Route path='/group/:id/new' element={<NewTransaction />} />
<Route path='*' element={<NotFound />} />
</Routes>
</BrowserRouter>
);
}