import { Stepper, Step, StepLabel, Button, TextField } from '@mui/material';
import { useState } from 'react';
const TransactionForm = () => {
const [activeStep, setActiveStep] = useState(0);
const steps = ['Details', 'Split', 'Confirm'];
return (
<div>
<Stepper activeStep={activeStep}>{steps.map(label => <Step key={label}><StepLabel>{label}</StepLabel></Step>)}</Stepper>
<TextField label='Amount' variant='outlined' fullWidth margin='normal'/>
<Button variant='contained' onClick={() => setActiveStep((s) => s + 1)}>Next</Button>
</div>);
};
export default TransactionForm;