using Xunit;
public class ExpenseServiceTests {
[Fact]
public void SplitEqual_ShouldDivideCorrectly() {
var service = new ExpenseService();
var result = service.SplitEqual(100, new List<int> {1,2});
Assert.Equal(50, result[1]);
Assert.Equal(50, result[2]);
}}