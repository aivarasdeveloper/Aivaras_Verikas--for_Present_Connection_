public class Startup {
public void ConfigureServices(IServiceCollection services) {
services.AddControllers();
services.AddDbContext<ExpenseDbContext>(opt => opt.UseInMemoryDatabase("ExpenseDB"));
services.AddEndpointsApiExplorer();
services.AddSwaggerGen();
}
public void Configure(IApplicationBuilder app, IWebHostEnvironment env) {
app.UseSwagger();
app.UseSwaggerUI();
app.UseRouting();
app.UseEndpoints(endpoints => { endpoints.MapControllers(); });
}}