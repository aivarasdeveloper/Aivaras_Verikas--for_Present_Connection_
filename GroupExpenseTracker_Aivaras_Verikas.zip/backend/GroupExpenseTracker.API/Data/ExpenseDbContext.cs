public class ExpenseDbContext : DbContext {
public ExpenseDbContext(DbContextOptions<ExpenseDbContext> options) : base(options) {}
public DbSet<Group> Groups { get; set; }
public DbSet<User> Users { get; set; }
public DbSet<Transaction> Transactions { get; set; }
protected override void OnModelCreating(ModelBuilder modelBuilder) {
modelBuilder.Entity<Group>().HasData(new Group { Id = 1, Title = "Trip to Palanga" });
modelBuilder.Entity<User>().HasData(new User { Id = 1, Name = "Aivaras" });
}}