using Microsoft.AspNetCore.Mvc;
[ApiController]
[Route("api/transactions")]
public class TransactionsController : ControllerBase {
[HttpGet] public IActionResult GetAll() => Ok(new[] { new { Id = 1, Amount = 100 } });
[HttpPost] public IActionResult Create([FromBody] object t) => Ok(t);
}