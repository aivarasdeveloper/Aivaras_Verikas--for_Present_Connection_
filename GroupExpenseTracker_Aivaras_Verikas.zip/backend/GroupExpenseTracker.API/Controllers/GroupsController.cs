using Microsoft.AspNetCore.Mvc;
[ApiController]
[Route("api/groups")]
public class GroupsController : ControllerBase {
[HttpGet] public IActionResult Get() => Ok(new[] { new { Id = 1, Title = "Trip" } });
[HttpPost] public IActionResult Post([FromBody] object g) => Ok(g);
[HttpDelete("{id}")] public IActionResult Delete(int id) => Ok(new { Deleted = id });
}