public class ExpenseService {
public Dictionary<int, decimal> SplitEqual(decimal amount, List<int> users) {
var share = amount / users.Count;
return users.ToDictionary(u => u, u => share);
}}