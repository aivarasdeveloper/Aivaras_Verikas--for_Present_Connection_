# Backend

Run:
```bash
dotnet restore
dotnet run
```
Accessible at http://localhost:5000