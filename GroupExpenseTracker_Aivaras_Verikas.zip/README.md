# Group Expense Tracker

This is a full-stack web application for tracking and splitting group expenses.

## 🚀 Technologies
- ASP.NET Core (C#)
- Entity Framework Core (In-Memory)
- React + TypeScript
- Material UI

## 📁 Project Structure
```
backend/   - ASP.NET Core API
frontend/  - React + TS frontend
```

## 🛠 Setup
### Backend:
```bash
cd backend/GroupExpenseTracker.API
dotnet restore
dotnet run
```

### Frontend:
```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:5173` (frontend) and `http://localhost:5000` (backend)

## 🔐 License
MIT